package presencial;

public class Main {
    public static void main(String[] args) {
        App sistema= new App();
        sistema.agregarEntero(52);
        sistema.agregarEntero(84);
        sistema.agregarEntero(9);
        sistema.agregarEntero(2);
        sistema.agregarEntero(2);
        sistema.agregarEntero(100);
    }
}
